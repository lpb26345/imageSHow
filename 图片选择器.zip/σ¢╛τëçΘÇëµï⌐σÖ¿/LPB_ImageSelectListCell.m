//
//  LPB_ImageSelectListCell.m
//  DeliciousLive
//
//  Created by lpb on 2017/8/6.
//  Copyright © 2017年 lpb. All rights reserved.
//

#import "LPB_ImageSelectListCell.h"

@implementation LPB_ImageSelectListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}


@end
