//
//  LPB_ImagePickerCollectionViewCell.h
//  SMoothBus
//
//  Created by lpb on 2017/2/10.
//  Copyright © 2017年 chengxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPB_ImagePickerCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *headerImage;

@property (weak, nonatomic) IBOutlet UIImageView *selectedImage;

@end
