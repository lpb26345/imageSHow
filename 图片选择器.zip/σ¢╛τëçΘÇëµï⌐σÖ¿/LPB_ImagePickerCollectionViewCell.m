//
//  LPB_ImagePickerCollectionViewCell.m
//  SMoothBus
//
//  Created by lpb on 2017/2/10.
//  Copyright © 2017年 chengxi. All rights reserved.
//

#import "LPB_ImagePickerCollectionViewCell.h"

@implementation LPB_ImagePickerCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
